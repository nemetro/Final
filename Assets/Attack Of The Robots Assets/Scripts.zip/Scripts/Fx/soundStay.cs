﻿using UnityEngine;
using System.Collections;

public class soundStay : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		DontDestroyOnLoad(this);
	}

}
