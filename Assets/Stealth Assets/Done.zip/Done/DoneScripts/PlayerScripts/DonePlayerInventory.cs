using UnityEngine;
using System.Collections;

public class DonePlayerInventory : MonoBehaviour
{
	public bool hasKey;			// Whether or not the player has the key.
}
